import withAuth from '../auth/withAuth';
const Login = () => {
  
    return (
      <div className='p-10'>
      </div>
    );
  };
  
  export default withAuth(Login);
  